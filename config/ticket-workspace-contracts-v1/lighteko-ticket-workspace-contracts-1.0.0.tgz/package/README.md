# Ticket navigator snapshot contract v1

Source pin: d27fe24e5cead1fae9ba86ac7b57ac5decf067d9

This package contains generated runtime validation, type declarations, an artifact, and fixtures for the ticket navigator snapshot v1 contract.
The package is marked `private: true` and `UNLICENSED`. This archive grants no rights to ticket-owned content. Use, copying, or redistribution requires separate written authorization from the rights holder.
Fixtures exercise schema and admission behavior only; they are not live state or caller authority.
The `./test-fixtures` export materializes the included corpus for tests and is not a product API.

Import `@lighteko/ticket-workspace-contracts/navigator-snapshot-v1` for the ticket-owned runtime validator.
